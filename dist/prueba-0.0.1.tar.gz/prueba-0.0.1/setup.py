from setuptools import setup

setup(
    author="Cristian",
    author_email="asd@eweq.com",
    description="prueba de creacion de paquete redistribuible",
    version="0.0.1",
    name="prueba",
    packages=['paquete']
)