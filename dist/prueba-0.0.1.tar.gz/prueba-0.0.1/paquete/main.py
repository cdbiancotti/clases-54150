from paquete import pepe

print(pepe.var)