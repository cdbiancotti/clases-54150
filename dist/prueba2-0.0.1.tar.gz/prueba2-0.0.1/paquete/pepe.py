
print('Cargue pepe!')

var = 1