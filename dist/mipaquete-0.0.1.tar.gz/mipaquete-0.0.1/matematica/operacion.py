var_de_operacion = 225

def sumar(a,b):
    return a+b


def restar(a,b):
    return a-b

class Cuadrado:
    def __init__(self, lado):
        self.lado = lado
        
    def perimetro(self):
        return self.lado * 4
